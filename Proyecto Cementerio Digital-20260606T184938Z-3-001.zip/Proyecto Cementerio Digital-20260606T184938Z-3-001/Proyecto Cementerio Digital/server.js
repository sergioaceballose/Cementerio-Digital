const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors());

// Servir archivos estáticos (HTML, CSS, JS) desde la carpeta actual
app.use(express.static(__dirname));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'cementerio_digital_uam',
    multipleStatements: true
});

db.connect((err) => {
    if (err) console.error('❌ Error BD:', err);
    else console.log('✅ Conectado a MySQL');
});

// RUTA RAIZ: Redirige al login automáticamente
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/interfazinicio.html');
});

// LOGIN
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    db.query('SELECT * FROM registros WHERE Usuario_academico = ? AND Contrasena = ?', [email, password], (err, results) => {
        if (err) return res.status(500).json({ success: false, message: 'Error BD' });
        if (results.length > 0) res.json({ success: true, nombre: results[0].nombre });
        else res.json({ success: false, message: 'Credenciales incorrectas' });
    });
});
// NUEVA RUTA: ELIMINAR CUENTA (para ciclo >= 365 días)
app.post('/api/eliminar-cuenta', (req, res) => {
    const { correo } = req.body;
    
    // Ejecutamos el DELETE directamente
    db.query('DELETE FROM registros_de_usuarios WHERE correo_institucional = ?', [correo], (err, result) => {
        if (err) return res.status(500).json({ message: "Error al eliminar de la base de datos" });
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Cuenta no encontrada" });
        }
        
        res.json({ message: "🗑️ Cuenta eliminada permanentemente del sistema" });
    });
});


// OBTENER ESTADÍSTICAS (Dashboard)
app.get('/api/estadisticas', (req, res) => {
    const sql = `
        SELECT 
            (SELECT COUNT(*) FROM registros_de_usuarios) as total,
            (SELECT COUNT(*) FROM registros_de_usuarios WHERE LOWER(estado) = 'inactivas') as inactivas,
            (SELECT COUNT(*) FROM registros_de_usuarios WHERE dias_inactividad >= 180) as para_migrar,
            (SELECT COUNT(*) FROM registros_de_usuarios WHERE dias_inactividad >= 365) as para_eliminacion
    `;
    
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results[0]);
    });
});
// OBTENER CUENTAS (Candidatos a migración)
// OBTENER CUENTAS (Solo candidatos a migrar: de 180 a 364 días)
app.get('/api/cuentas', (req, res) => {
    // Usamos AND para establecer un techo (menor a 365)
    const sql = `SELECT nombre, correo_institucional, dias_inactividad 
                 FROM registros_de_usuarios 
                 WHERE dias_inactividad >= 180 AND dias_inactividad < 365`;
    
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});
// MIGRAR (Atómico y Seguro)
app.post('/api/migrar-uno', (req, res) => {
    const { correo } = req.body;
    
    // Desactivamos el modo seguro de MySQL para permitir DELETE
    db.query('SET SQL_SAFE_UPDATES = 0', (err) => {
        if (err) return res.status(500).json({ message: "Error al configurar seguridad BD" });

        db.beginTransaction((err) => {
            if (err) return res.status(500).json({ message: "Error al iniciar transacción" });

            const sqlInsert = `INSERT INTO almacenamiento_congelado (correo_institucional, dias_inactividad, estado_original) 
                               SELECT correo_institucional, dias_inactividad, estado 
                               FROM registros_de_usuarios WHERE correo_institucional = ?`;

            db.query(sqlInsert, [correo], (err, result) => {
                if (err || result.affectedRows === 0) {
                    return db.rollback(() => res.status(500).json({ message: "Error al insertar o usuario ya migrado" }));
                }

                db.query('DELETE FROM registros_de_usuarios WHERE correo_institucional = ?', [correo], (err2) => {
                    if (err2) return db.rollback(() => res.status(500).json({ message: "Error al borrar origen" }));
                    
                    db.commit((err3) => {
                        if (err3) return db.rollback(() => res.status(500).json({ message: "Error al confirmar cambios" }));
                        res.json({ message: "✅ Migración exitosa, Correo enviado al Cold Server" });
                    });
                });
            });
        });
    });
});

app.listen(3000, () => console.log('🚀 Servidor corriendo en http://localhost:3000'));