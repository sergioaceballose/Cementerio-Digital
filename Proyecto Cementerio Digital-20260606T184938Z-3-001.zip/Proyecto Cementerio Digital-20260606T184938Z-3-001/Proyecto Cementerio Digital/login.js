document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('user').value.trim();
            const password = document.getElementById('pass').value.trim();

            const res = await fetch('http://localhost:3000/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })   
            });
            const data = await res.json();

            if (data.success) {
                sessionStorage.setItem('usuarioLogueado', data.nombre);
                window.location.href = 'interfazprincipal.html'; 
            } else {
                alert(data.message);
            }
        });
    }
});