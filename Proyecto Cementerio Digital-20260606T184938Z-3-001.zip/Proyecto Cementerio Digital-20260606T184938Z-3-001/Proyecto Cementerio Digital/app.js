// Esperamos a que todo el DOM (HTML) esté completamente cargado
document.addEventListener('DOMContentLoaded', () => {
    
    // 1. GESTIÓN DE BOTONES "NOTIFICAR"
    const notifyButtons = document.querySelectorAll('.js-btn-notify');
    
    notifyButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            // Obtenemos el email de la fila actual para personalizar la alerta
            const row = event.target.closest('tr');
            const userEmail = row.cells[0].textContent;
            
            alert(`📨 Notificación enviada con éxito al correo alternativo de: ${userEmail}`);
        });
    });

    // 2. GESTIÓN DE BOTONES "MOVER A COLD SERVER"
    const coldButtons = document.querySelectorAll('.js-btn-cold');
    
    coldButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            const currentButton = event.target;
            const row = currentButton.closest('tr');
            const userEmail = row.cells[0].textContent;

            // Confirmación antes de realizar la acción técnica
            const confirmAction = confirm(`¿Está seguro de que desea mover la cuenta ${userEmail} al Cold Server?`);
            
            if (confirmAction) {
                // Aplicamos el cambio visual (atenuar la fila)
                row.style.transition = 'all 0.5s ease';
                row.style.opacity = '0.4';
                row.style.backgroundColor = '#f4f6f9';
                
                // Deshabilitamos los botones de esa fila para evitar clics repetidos
                const rowButtons = row.querySelectorAll('button');
                rowButtons.forEach(btn => {
                    btn.disabled = true;
                    btn.style.cursor = 'not-allowed';
                    if(btn.classList.contains('btn-cold')) {
                        btn.textContent = 'En Cold Server';
                        btn.style.background = '#7f8c8d';
                    }
                });

                alert(`❄️ La cuenta de ${userEmail} ha sido trasladada al Cold Server satisfactoriamente.`);
            }
        });
    });

    // 3. EXTRA: FILTRADO DINÁMICO DE LA TABLA (Buscador en tiempo real)
    const searchInput = document.querySelector('.search-box input');
    
    if (searchInput) {
        searchInput.addEventListener('input', (event) => {
            const searchTerm = event.target.value.toLowerCase();
            const tableRows = document.querySelectorAll('tbody tr');

            tableRows.forEach(row => {
                const emailText = row.cells[0].textContent.toLowerCase();
                const statusText = row.cells[1].textContent.toLowerCase();
                
                // Si el término coincide con el correo o el estado, muestra la fila; si no, la oculta
                if (emailText.includes(searchTerm) || statusText.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});